const express = require("express");
const axios = require("axios");
const cors = require("cors");
const NodeCache = require("node-cache");

const app = express();
const port = process.env.PORT || 4000;
const cache = new NodeCache({ stdTTL: 300 }); // Cache de 5 minutos

app.use(cors());
app.use(express.json());

const caixaAPI = axios.create({
  baseURL: "https://servicebus2.caixa.gov.br/portaldeloterias/api",
  headers: {
    "Host": "servicebus2.caixa.gov.br",
    "Origin": "https://servicebus2.caixa.gov.br",
    "Referer": "https://servicebus2.caixa.gov.br/portaldeloterias/api"
  }
});

// Lista de loterias válidas (para validação)
const loteriasValidas = [
  "megasena",
  "lotofacil",
  "quina",
  "lotomania",
  "timemania",
  "diadesorte",
  "duplasena",
  "supersete",
  "mais-milionaria"
];

app.get("/api/:loteria/:concurso?", async (req, res) => { // Mudança aqui: adicionando /api e tornando concurso opcional
  try {
    const loteria = req.params.loteria.toLowerCase(); // Converte para minúsculas
    const concurso = req.params.concurso; // Agora concurso é um parâmetro de rota
    const cacheKey = concurso ? `${loteria}-${concurso}` : loteria;

    // Validação da loteria
    if (!loteriasValidas.includes(loteria)) {
      return res.status(400).json({ error: "Loteria inválida", validLoterias: loteriasValidas });
    }

    const cachedData = cache.get(cacheKey);
    if (cachedData) {
      console.log(`Returning cached data for ${cacheKey}`);
      return res.json(cachedData);
    }

    let url = `/${loteria}`;
    if (concurso) {
      url += `/${concurso}`;
    }

    console.log(`Fetching data from Caixa API: ${url}`);
    const response = await caixaAPI.get(url);
    cache.set(cacheKey, response.data);
    res.json(response.data);
  } catch (error) {
    console.error(`Error fetching ${req.params.loteria} data:`, error.message);
    res.status(500).json({
      error: `Error fetching ${req.params.loteria} data`,
      message: error.message,
      stack: process.env.NODE_ENV === "production" ? undefined : error.stack
    });
  }
});

app.get("/api/", (req, res) => { // Mudança aqui: adicionando /api
  res.json({ status: "online", message: "Lottery API is working!" });
});

app.listen(port, "0.0.0.0", () => {
  console.log(`Server running on port ${port}`);
});
